import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { AboutSection } from "./index";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — Al Habib Restaurants | Our Story" },
      {
        name: "description",
        content:
          "Our story: Al Habib Restaurants serves authentic Pakistani and Desi cuisine with traditional recipes, generous portions and warm family service in Al-Khobar.",
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <div className="pt-[70px]">
        <AboutSection />
      </div>
      <Footer />
    </div>
  );
}
