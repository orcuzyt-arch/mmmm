import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { LocationSection } from "./index";

export const Route = createFileRoute("/location")({
  head: () => ({
    meta: [
      { title: "Find Us — Al Habib Restaurants | Al-Thuqbah, Al Khobar" },
      {
        name: "description",
        content:
          "Visit Al Habib Restaurants at 75CV+R7Q Yanbu St, Al-Thuqbah, Al Khobar. Open daily 12 PM–12 AM. Family seating, walk-ins welcome.",
      },
    ],
  }),
  component: LocationPage,
});

function LocationPage() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <div className="pt-[70px]">
        <LocationSection />
      </div>
      <Footer />
    </div>
  );
}
