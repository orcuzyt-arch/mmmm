import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { ReviewsSection } from "./index";

export const Route = createFileRoute("/reviews")({
  head: () => ({
    meta: [
      { title: "Guest Reviews — Al Habib Restaurants | What Our Guests Say" },
      {
        name: "description",
        content:
          "Read what our guests are saying about Al Habib Restaurants in Al-Khobar — 5-star reviews on food, family atmosphere and unbeatable value.",
      },
    ],
  }),
  component: ReviewsPage,
});

function ReviewsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <div className="pt-[70px]">
        <ReviewsSection />
      </div>
      <Footer />
    </div>
  );
}
