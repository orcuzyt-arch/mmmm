import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import dishKarahi from "@/assets/dish-karahi.jpg";
import dishBiryani from "@/assets/dish-biryani.jpg";
import dishBbq from "@/assets/dish-bbq.jpg";
import dishCurry from "@/assets/dish-curry.jpg";
import dishNihari from "@/assets/dish-nihari.jpg";
import dishHaleem from "@/assets/dish-haleem.jpg";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Full Menu — Al Habib Restaurants | قائمة الطعام" },
      {
        name: "description",
        content:
          "Browse the full Al Habib Restaurants menu — grills, karahi, biryani, curries and more. Fresh, authentic Pakistani food made to order in Al-Khobar.",
      },
    ],
  }),
  component: MenuPage,
});

type Item = {
  name: string;
  desc: string;
  price: string;
  img?: string;
  emoji?: string;
  tags?: { label: string; variant?: "default" | "hot" | "star" }[];
};

type Category = {
  key: string;
  icon: string;
  title: string;
  items: Item[];
  comingSoon?: string;
};

const categories: Category[] = [
  {
    key: "grills",
    icon: "🔥",
    title: "Grills & BBQ",
    items: [
      {
        name: "Chapli Kabab",
        desc: "Juicy, well-seasoned kababs cooked to perfection. Served with fresh naan and chutney.",
        price: "15",
        img: dishBbq,
        tags: [{ label: "Grill" }, { label: "🌶 Spicy", variant: "hot" }],
      },
    ],
    comingSoon: "More grill items coming soon — seekh kabab, malai boti and more on the way.",
  },
  {
    key: "curries",
    icon: "🍛",
    title: "Curries & Karahi",
    items: [
      {
        name: "Mutton Karahi",
        desc: "Slow-cooked mutton in a rich tomato-ginger gravy with fresh green chilies.",
        price: "22",
        img: dishKarahi,
        tags: [{ label: "Karahi" }, { label: "⭐ Best Seller", variant: "star" }],
      },
      {
        name: "Chicken Tikka Masala",
        desc: "Tender chicken in a creamy, spiced tomato gravy. Served with naan.",
        price: "18",
        img: dishCurry,
        tags: [{ label: "Curry" }],
      },
      {
        name: "Beef Nihari",
        desc: "Traditional slow-cooked beef stew, rich and aromatic. Garnished with ginger and lemon.",
        price: "20",
        img: dishNihari,
        tags: [{ label: "Curry" }, { label: "🌶 Spicy", variant: "hot" }],
      },
      {
        name: "Haleem",
        desc: "Hearty lentil and beef stew, slow-cooked to a perfect blend of flavors.",
        price: "16",
        img: dishHaleem,
        tags: [{ label: "Stew" }],
      },
    ],
  },
  {
    key: "rice",
    icon: "🍚",
    title: "Rice & Bread",
    items: [
      {
        name: "Chicken Biryani",
        desc: "Fragrant basmati rice layered with spiced chicken, saffron and fried onions.",
        price: "18",
        img: dishBiryani,
        tags: [{ label: "Rice" }, { label: "⭐ Signature", variant: "star" }],
      },
    ],
    comingSoon: "Mutton biryani, naan, roti and paratha coming soon.",
  },
  {
    key: "starters",
    icon: "🥗",
    title: "Starters & Sides",
    items: [],
    comingSoon: "We're keeping this space for our starters and sides.",
  },
  {
    key: "drinks",
    icon: "🥤",
    title: "Drinks & Juices",
    items: [],
    comingSoon: "We're keeping this space for our drinks and beverages.",
  },
];

function MenuPage() {
  const [filter, setFilter] = useState<string>("all");

  const visible = filter === "all" ? categories : categories.filter((c) => c.key === filter);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* MENU HERO */}
      <div className="relative min-h-[300px] flex flex-col items-center justify-center text-center px-[6%] pt-[100px] pb-14 bg-[color:var(--habib-black)] overflow-hidden">
        <div
          aria-hidden
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              "radial-gradient(ellipse at center, rgba(245,168,0,0.17) 0%, transparent 65%)",
          }}
        />
        <h1
          style={{ fontFamily: "var(--font-display)" }}
          className="text-[clamp(2.8rem,5vw,4.5rem)] font-black text-white leading-[1.1] mb-3 relative z-[2]"
        >
          Our <em className="not-italic text-[color:var(--habib-yellow)]">Full Menu</em>
        </h1>
        <p
          style={{ fontFamily: "var(--font-arabic)", direction: "rtl" }}
          className="text-2xl font-bold text-white/50 mb-4 relative z-[2]"
        >
          قائمة الطعام الكاملة
        </p>
        <p className="text-base text-white/60 relative z-[2]">
          Fresh, authentic, made to order — every single time.
        </p>
      </div>

      {/* FILTERS */}
      <div className="flex justify-center gap-2.5 flex-wrap px-[6%] py-7 bg-white sticky top-[70px] z-40 border-b border-[#EDEDED]">
        {[
          { k: "all", label: "All" },
          { k: "grills", label: "🔥 Grills" },
          { k: "curries", label: "🍛 Curries" },
          { k: "rice", label: "🍚 Rice & Bread" },
          { k: "starters", label: "🥗 Starters" },
          { k: "drinks", label: "🥤 Drinks" },
        ].map((b) => (
          <button
            key={b.k}
            type="button"
            onClick={() => setFilter(b.k)}
            className={`px-5 py-2 rounded-full font-bold text-[0.88rem] border-2 transition-all ${
              filter === b.k
                ? "bg-[color:var(--habib-yellow)] border-[color:var(--habib-yellow)] text-[color:var(--habib-black)]"
                : "border-[#E0E0E0] bg-transparent text-[color:var(--habib-grey)] hover:bg-[color:var(--habib-yellow)] hover:border-[color:var(--habib-yellow)] hover:text-[color:var(--habib-black)]"
            }`}
          >
            {b.label}
          </button>
        ))}
      </div>

      {/* MENU BODY */}
      <div className="px-[6%] py-14 bg-white">
        {visible.map((cat) => (
          <div key={cat.key} className="mb-16">
            <div className="flex items-center gap-4 mb-7 pb-4 border-b-2 border-[color:var(--habib-yellow-light)]">
              <span className="text-[1.9rem]">{cat.icon}</span>
              <h2
                style={{ fontFamily: "var(--font-display)" }}
                className="text-[1.82rem] font-black text-[color:var(--habib-black)]"
              >
                {cat.title}
              </h2>
              {cat.comingSoon && (
                <span className="ml-auto bg-[color:var(--habib-yellow-light)] text-[color:var(--habib-yellow)] text-[0.72rem] font-extrabold tracking-wider uppercase px-3 py-1 rounded-full">
                  More Coming Soon
                </span>
              )}
            </div>

            <div className="flex flex-col gap-3.5">
              {cat.items.map((item) => (
                <div
                  key={item.name}
                  className="flex items-center gap-5 bg-[#F2F2EF] rounded-2xl p-5 border-2 border-transparent hover:border-[color:var(--habib-yellow)]/40 hover:translate-x-1 hover:shadow-[0_8px_32px_rgba(245,168,0,0.09)] transition-all"
                >
                  {item.img ? (
                    <img
                      src={item.img}
                      alt={item.name}
                      width={768}
                      height={768}
                      loading="lazy"
                      className="w-20 h-20 rounded-2xl object-cover flex-shrink-0"
                    />
                  ) : (
                    <div className="w-20 h-20 rounded-2xl bg-[color:var(--habib-yellow-light)] flex items-center justify-center text-3xl flex-shrink-0">
                      {item.emoji ?? "🍽️"}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <div
                      style={{ fontFamily: "var(--font-display)" }}
                      className="text-[1.05rem] font-bold text-[color:var(--habib-black)] mb-1"
                    >
                      {item.name}
                    </div>
                    <div className="text-[0.82rem] text-[color:var(--habib-grey)] leading-[1.5]">
                      {item.desc}
                    </div>
                    {item.tags && (
                      <div className="flex gap-1.5 mt-2 flex-wrap">
                        {item.tags.map((t) => (
                          <span
                            key={t.label}
                            className={`text-[0.67rem] font-extrabold tracking-wider uppercase px-2 py-0.5 rounded-full ${
                              t.variant === "hot"
                                ? "bg-[#FFF0EC] text-[#E85D26]"
                                : t.variant === "star"
                                  ? "bg-[#EBF9F1] text-[#1A7A46]"
                                  : "bg-[color:var(--habib-yellow-light)] text-[color:var(--habib-yellow)]"
                            }`}
                          >
                            {t.label}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                  <div
                    style={{ fontFamily: "var(--font-display)" }}
                    className="text-[1.3rem] font-black text-[color:var(--habib-black)] whitespace-nowrap flex-shrink-0"
                  >
                    <span className="text-[0.8rem] font-bold text-[color:var(--habib-grey)]" style={{ fontFamily: "var(--font-body)" }}>
                      SAR{" "}
                    </span>
                    {item.price}
                  </div>
                </div>
              ))}

              {cat.comingSoon && (
                <div className="bg-[color:var(--habib-yellow-light)] border-2 border-dashed border-[color:var(--habib-yellow)]/40 rounded-2xl p-9 text-center">
                  <div className="text-[2.4rem] mb-3">{cat.icon}</div>
                  <h4
                    style={{ fontFamily: "var(--font-display)" }}
                    className="text-[1.22rem] font-black text-[color:var(--habib-black)] mb-1.5"
                  >
                    More Coming Soon
                  </h4>
                  <p className="text-[0.85rem] text-[color:var(--habib-grey)]">{cat.comingSoon}</p>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <Footer />
    </div>
  );
}
