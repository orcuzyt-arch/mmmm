import { createFileRoute, Link } from "@tanstack/react-router";

import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import dishKarahi from "@/assets/dish-karahi.jpg";
import dishBiryani from "@/assets/dish-biryani.jpg";
import dishBbq from "@/assets/dish-bbq.jpg";
import dishCurry from "@/assets/dish-curry.jpg";
import dishNihari from "@/assets/dish-nihari.jpg";
import dishHaleem from "@/assets/dish-haleem.jpg";
import restaurantInterior from "@/assets/restaurant-interior.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Al Habib Restaurants | مطاعم الحبيب — Authentic Pakistani in Al-Khobar" },
      {
        name: "description",
        content:
          "Taste the warmth of real desi cooking at Al Habib Restaurants in Al-Khobar — juicy Chapli Kabab, rich Mutton Karahi and more, with generous portions at unbeatable prices.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />

      {/* HERO */}
      <section
        className="relative min-h-screen flex items-center overflow-hidden pt-[70px] px-[6%]"
        style={{ background: "var(--habib-yellow-pale)" }}
      >
        <div
          aria-hidden
          className="pointer-events-none absolute z-0"
          style={{
            top: "-10%",
            right: "-5%",
            width: "75%",
            height: "110%",
            background:
              "radial-gradient(ellipse at 70% 50%, rgba(245,168,0,0.22) 0%, rgba(255,220,100,0.1) 40%, transparent 70%)",
          }}
        />
        <div
          aria-hidden
          className="absolute left-0 right-0 -bottom-[2px] h-20 bg-white z-[2] pointer-events-none"
          style={{ clipPath: "ellipse(55% 100% at 50% 100%)" }}
        />

        <div className="relative z-[3] w-full grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <div className="max-w-[560px] pb-16 lg:pb-24">
            <div className="hero-badge mb-6">
              <span aria-hidden>⭐</span>
              <span>Rated 5/5 by Our Guests</span>
            </div>
            <h1
              style={{ fontFamily: "var(--font-display)" }}
              className="font-black leading-[1.08] text-[color:var(--habib-black)] mb-3"
            >
              <span className="block text-[clamp(2.6rem,4.5vw,4.2rem)]">
                Taste the <em className="not-italic text-[color:var(--habib-yellow)]">Warmth</em>
              </span>
              <span className="block text-[clamp(2.6rem,4.5vw,4.2rem)]">of Real Desi Cooking</span>
            </h1>
            <div
              style={{ fontFamily: "var(--font-arabic)", direction: "rtl" }}
              className="text-[clamp(1.3rem,2.2vw,2rem)] font-bold text-[color:var(--habib-charcoal)] mb-5"
            >
              مطاعم الحبيب — الخبر
            </div>
            <p className="text-[1.05rem] text-[color:var(--habib-grey)] leading-[1.75] mb-8">
              Authentic Pakistani flavors — juicy Chapli Kabab, rich Mutton Karahi, and much more.
              Family dining with generous portions and unbeatable prices in Al-Khobar.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link to="/menu" className="btn-habib btn-habib-dark">
                <span aria-hidden>🍛</span>
                <span>Explore Full Menu</span>
              </Link>
              <Link to="/location" className="btn-habib btn-habib-outline">
                <span aria-hidden>📍</span>
                <span>Find Us</span>
              </Link>
            </div>
          </div>

          <div aria-hidden className="hidden lg:block" />
        </div>

      </section>

      {/* STATS BAR */}
      <div className="bg-[color:var(--habib-black)] text-white px-[6%] py-7 flex justify-around items-center flex-wrap gap-5 relative z-[3]">
        {[
          { n: "5/5", l: "Guest Ratings" },
          { n: "100%", l: "Authentic Desi" },
          { n: "Family", l: "Friendly Seating" },
          { n: "Al Khobar", l: "Eastern Province, KSA" },
        ].map((s, i, arr) => (
          <div key={s.l} className="flex items-center gap-5">
            <div className="text-center">
              <div
                style={{ fontFamily: "var(--font-display)" }}
                className="font-black text-[2.3rem] text-[color:var(--habib-yellow)] leading-none"
              >
                {s.n}
              </div>
              <div className="text-xs font-semibold text-white/60 mt-1 tracking-wide">{s.l}</div>
            </div>
            {i < arr.length - 1 && <div className="hidden md:block w-px h-12 bg-white/15" />}
          </div>
        ))}
      </div>

      {/* ABOUT */}
      <AboutSection />

      {/* SPECIALS */}
      <SpecialsSection />

      {/* REVIEWS */}
      <ReviewsSection />

      {/* LOCATION */}
      <LocationSection />

      <Footer />
    </div>
  );
}

export function AboutSection() {
  return (
    <section id="about" className="py-[88px] px-[6%]" style={{ background: "var(--habib-yellow-pale)" }}>
      <div className="grid lg:grid-cols-2 gap-16 items-center">
        <div className="relative pb-10">
          <img
            src={restaurantInterior}
            alt="Al Habib restaurant interior"
            width={1024}
            height={768}
            loading="lazy"
            className="w-full h-[420px] object-cover rounded-3xl shadow-[0_24px_64px_rgba(0,0,0,0.19)] block"
          />
          <img
            src={dishKarahi}
            alt="Chicken Karahi"
            width={768}
            height={768}
            loading="lazy"
            className="absolute bottom-0 -right-5 w-[155px] h-[155px] object-cover rounded-2xl border-[5px] border-white shadow-[0_12px_40px_rgba(0,0,0,0.15)]"
          />
          <div className="absolute -top-5 -left-5 bg-[color:var(--habib-yellow)] text-[color:var(--habib-black)] font-black px-4 py-3 rounded-2xl shadow-[0_8px_30px_rgba(245,168,0,0.44)] text-center leading-tight">
            <span style={{ fontFamily: "var(--font-display)" }} className="block text-[2rem] leading-none">
              5.0
            </span>
            ⭐ Rated<br />by Guests
          </div>
        </div>
        <div>
          <SectionPill>🍴 Our Story</SectionPill>
          <SectionTitle>
            Where Every Meal<br />Feels Like Home
          </SectionTitle>
          <p className="text-base text-[color:var(--habib-grey)] leading-[1.75] max-w-[500px]">
            At Al Habib Restaurants in Al-Khobar, we bring you the richest flavors of Pakistani and
            Desi cuisine. From sizzling Mutton Karahi to perfectly-spiced Chapli Kabab — every dish
            is crafted with authentic spices, generous portions, and real love.
          </p>
          <div className="grid sm:grid-cols-2 gap-3.5 mt-6">
            {[
              { i: "🧑‍🍳", t: "Authentic Recipes", d: "Traditional spices and techniques passed down through generations." },
              { i: "💰", t: "Affordable Prices", d: "Exceptional quality at prices that bring the whole family together." },
              { i: "🏡", t: "Family Atmosphere", d: "Comfortable family seating with warm, welcoming service." },
              { i: "🔥", t: "Made Fresh Daily", d: "Every dish cooked to order — nothing pre-made, ever." },
            ].map((f) => (
              <div
                key={f.t}
                className="bg-white rounded-2xl p-5 border-2 border-transparent hover:border-[color:var(--habib-yellow)] hover:-translate-y-1 hover:shadow-[0_12px_36px_rgba(245,168,0,0.12)] transition-all"
              >
                <div className="w-[42px] h-[42px] bg-[color:var(--habib-yellow-light)] rounded-xl flex items-center justify-center text-[1.3rem] mb-2.5">
                  {f.i}
                </div>
                <h4 className="text-[0.9rem] font-extrabold text-[color:var(--habib-black)] mb-1">
                  {f.t}
                </h4>
                <p className="text-[0.8rem] text-[color:var(--habib-grey)] leading-[1.5]">{f.d}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export function SpecialsSection() {
  const specials = [
    { img: dishKarahi, badge: "⭐ Best Seller", cat: "Karahi", name: "Mutton Karahi", desc: "Slow-cooked mutton in a rich tomato-ginger gravy with fresh chilies.", price: "22" },
    { img: dishBbq, badge: "🔥 Popular", cat: "Grills", name: "Chapli Kabab", desc: "Juicy, flame-grilled minced meat patties with traditional spices.", price: "15" },
    { img: dishBiryani, badge: "🌟 Signature", cat: "Rice", name: "Chicken Biryani", desc: "Fragrant basmati rice layered with spiced chicken and saffron.", price: "18" },
  ];
  return (
    <section className="py-[88px] px-[6%] bg-white">
      <div className="flex items-end justify-between flex-wrap gap-4 mb-9">
        <div>
          <SectionPill>🌟 House Specials</SectionPill>
          <SectionTitle>A Taste of What Awaits</SectionTitle>
          <p className="text-base text-[color:var(--habib-grey)] leading-[1.75] max-w-[500px]">
            Just a few of the dishes our guests keep coming back for.
          </p>
        </div>
        <Link to="/menu" className="btn-habib bg-[color:var(--habib-yellow)] text-[color:var(--habib-black)] shadow-[0_6px_24px_rgba(245,168,0,0.42)] hover:shadow-[0_12px_36px_rgba(245,168,0,0.56)]">
          <span>See Full Menu →</span>
        </Link>
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {specials.map((s) => (
          <div
            key={s.name}
            className="rounded-3xl overflow-hidden bg-[color:var(--gl,#F2F2EF)] hover:-translate-y-2 hover:shadow-[0_24px_60px_rgba(0,0,0,0.12)] transition-all cursor-pointer group"
            style={{ background: "#F2F2EF" }}
          >
            <div className="relative overflow-hidden h-[220px]">
              <span className="absolute top-3 left-3 z-[2] bg-[color:var(--habib-yellow)] text-[color:var(--habib-black)] text-[0.68rem] font-extrabold px-2.5 py-1 rounded-full">
                {s.badge}
              </span>
              <img
                src={s.img}
                alt={s.name}
                width={768}
                height={768}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.07]"
              />
            </div>
            <div className="p-5">
              <div className="text-[0.68rem] font-extrabold tracking-[1.5px] uppercase text-[color:var(--habib-yellow)] mb-1">
                {s.cat}
              </div>
              <h3 style={{ fontFamily: "var(--font-display)" }} className="text-[1.1rem] font-bold text-[color:var(--habib-black)] mb-1.5">
                {s.name}
              </h3>
              <p className="text-[0.81rem] text-[color:var(--habib-grey)] leading-[1.5] mb-3.5">
                {s.desc}
              </p>
              <div className="flex items-center justify-between">
                <div className="font-black text-[1.1rem] text-[color:var(--habib-black)]">
                  SAR {s.price} <span className="text-[0.77rem] font-semibold text-[color:var(--habib-grey)]">/ serving</span>
                </div>
                <Link to="/menu" className="btn-habib bg-[color:var(--habib-yellow)] text-[color:var(--habib-black)] !py-2 !px-4 !text-[0.82rem]">
                  <span>View</span>
                </Link>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export function ReviewsSection() {
  const reviews = [
    { initial: "U", name: "Umair Ishaq", meta: "Local Guide · Food 5/5 · Service 5/5 · Atmosphere 5/5", text: "The environment for family sitting is extremely good. The very reasonable prices and good quantity of food truly impressed me. Highly recommended!" },
    { initial: "T", name: "Theis Solling", meta: "Local Guide · 377 reviews · Dinner", text: "The first but absolutely not my last visit 🤩 The big plate with mixed grilled and rice is delicious. And yummy bread 😋" },
    { initial: "أ", name: "أحمد كبير بن محمد", meta: "Local Guide · 16 reviews · Lunch", text: "Absolutely fantastic! The Chicken Kadai was rich and flavorful. The Chapli Kabab was juicy and cooked to perfection. Highly recommended!" },
    { initial: "U", name: "Umair Ishaq", meta: "Local Guide · Lunch · SAR 1–20", text: "Pakistani fantastic flavor with very reasonable prices. Fresh, delicious, truly satisfying. Generous quantity and outstanding quality." },
  ];
  const doubled = [...reviews, ...reviews];
  return (
    <section id="reviews" className="py-[88px] px-[6%] bg-[color:var(--habib-black)]">
      <div className="text-center mb-12">
        <span className="inline-flex items-center gap-1.5 bg-[color:var(--habib-yellow)]/15 text-[color:var(--habib-yellow)] text-[0.73rem] font-extrabold tracking-[2px] uppercase px-3.5 py-1 rounded-full mb-3.5">
          💬 Guest Reviews
        </span>
        <h2 style={{ fontFamily: "var(--font-display)" }} className="text-[clamp(1.9rem,3.2vw,2.85rem)] font-black text-white leading-[1.15]">
          What Our Guests Say
        </h2>
      </div>
      <div className="rev-outer overflow-hidden relative">
        <div className="rev-track flex gap-5 w-max">
          {doubled.map((r, i) => (
            <div
              key={i}
              className="bg-white/5 border border-white/10 rounded-3xl p-6 w-[330px] flex-shrink-0 hover:bg-[color:var(--habib-yellow)]/10 hover:border-[color:var(--habib-yellow)]/30 transition-colors"
            >
              <div className="text-[color:var(--habib-yellow)] text-[0.95rem] mb-3 tracking-[2px]">
                ★★★★★
              </div>
              <p className="text-[0.91rem] leading-[1.7] text-white/80 mb-4">"{r.text}"</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[color:var(--habib-yellow)] flex items-center justify-center font-black text-[0.93rem] text-[color:var(--habib-black)] flex-shrink-0">
                  {r.initial}
                </div>
                <div>
                  <div className="font-bold text-[0.86rem] text-white">{r.name}</div>
                  <div className="text-[0.73rem] text-white/40 mt-0.5">{r.meta}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function LocationSection() {
  return (
    <section id="location" className="py-[88px] px-[6%]" style={{ background: "var(--habib-yellow-pale)" }}>
      <SectionPill>📍 Visit Us</SectionPill>
      <SectionTitle>Find Al Habib Restaurants</SectionTitle>
      <div className="grid lg:grid-cols-2 gap-12 items-center mt-11">
        <div className="flex flex-col gap-6">
          {[
            { i: "📍", l: "Address", v: "75CV+R7Q, Yanbu St\nAl-Thuqbah, Al Khobar 34624\nSaudi Arabia" },
            { i: "⏰", l: "Opening Hours", v: "Daily: 12:00 PM – 12:00 AM\nLunch & Dinner available" },
            { i: "🚗", l: "Parking", v: "Street parking on Yanbu St\nEasy access from main road" },
            { i: "👨‍👩‍👧", l: "Seating", v: "Dedicated family sections available\nWalk-ins warmly welcome" },
          ].map((it) => (
            <div key={it.l} className="flex gap-4 items-start">
              <div className="w-12 h-12 bg-[color:var(--habib-yellow)] rounded-2xl flex items-center justify-center text-[1.3rem] flex-shrink-0">
                {it.i}
              </div>
              <div>
                <div className="text-[0.7rem] font-extrabold tracking-[1.5px] uppercase text-[color:var(--habib-yellow)] mb-1">
                  {it.l}
                </div>
                <div className="text-[0.95rem] font-bold text-[color:var(--habib-black)] leading-[1.55] whitespace-pre-line">
                  {it.v}
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="rounded-3xl overflow-hidden shadow-[0_20px_60px_rgba(0,0,0,0.13)] h-[380px]">
          <iframe
            title="Al Habib Restaurants location"
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3573.0963!2d50.21800!3d26.28300!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49e8b6fc0dd22d%3A0x7e149a820d4e9e6d!2sAl-Thuqbah%2C%20Al%20Khobar!5e0!3m2!1sen!2ssa!4v1713609600000"
            className="w-full h-full border-0"
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </section>
  );
}

export function SectionPill({ children }: { children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 bg-[color:var(--habib-yellow-light)] text-[color:var(--habib-yellow)] text-[0.73rem] font-extrabold tracking-[2px] uppercase px-3.5 py-1 rounded-full mb-3.5">
      {children}
    </span>
  );
}

export function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2
      style={{ fontFamily: "var(--font-display)" }}
      className="text-[clamp(1.9rem,3.2vw,2.85rem)] font-black text-[color:var(--habib-black)] leading-[1.15] mb-3.5"
    >
      {children}
    </h2>
  );
}

// Re-export dish images so menu route can use them
export { dishKarahi, dishBiryani, dishBbq, dishCurry, dishNihari, dishHaleem };
