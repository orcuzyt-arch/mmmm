import { Link } from "@tanstack/react-router";
import habibLogo from "@/assets/habib-logo.png";

export function Footer() {
  return (
    <footer className="bg-[color:var(--habib-black)] text-white px-[6%] py-16">
      <div className="max-w-6xl mx-auto grid gap-10 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <img src={habibLogo} alt="" width={48} height={48} className="h-12 w-auto" />
            <div>
              <div style={{ fontFamily: "var(--font-display)" }} className="font-black text-lg">Al Habib Restaurants</div>
              <div style={{ fontFamily: "var(--font-arabic)", direction: "rtl" }} className="text-xs text-white/60">مطاعم الحبيب</div>
            </div>
          </div>
          <p className="text-white/70 text-sm leading-relaxed">
            Authentic Pakistani flavors served fresh every day in Al-Khobar.
          </p>
        </div>
        <div>
          <div className="font-bold mb-4 text-[color:var(--habib-yellow)]">Explore</div>
          <ul className="space-y-2 text-sm text-white/80">
            <li><Link to="/about" className="hover:text-[color:var(--habib-yellow)]">About Us</Link></li>
            <li><Link to="/menu" className="hover:text-[color:var(--habib-yellow)]">Our Menu</Link></li>
            <li><Link to="/reviews" className="hover:text-[color:var(--habib-yellow)]">Guest Reviews</Link></li>
            <li><Link to="/location" className="hover:text-[color:var(--habib-yellow)]">Find Us</Link></li>
          </ul>
        </div>
        <div>
          <div className="font-bold mb-4 text-[color:var(--habib-yellow)]">Visit Us</div>
          <p className="text-sm text-white/80 leading-relaxed">
            Al-Khobar, Eastern Province<br />
            Saudi Arabia
          </p>
          <p className="text-sm text-white/80 mt-3">Open daily · 11:00 AM – 1:00 AM</p>
        </div>
      </div>
      <div className="max-w-6xl mx-auto mt-12 pt-6 border-t border-white/10 text-xs text-white/50 text-center">
        © {new Date().getFullYear()} Al Habib Restaurants. All rights reserved.
      </div>
    </footer>
  );
}
