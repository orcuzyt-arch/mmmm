import { Link } from "@tanstack/react-router";
import habibLogo from "@/assets/habib-logo.png";

const links = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/menu", label: "Menu" },
  { to: "/reviews", label: "Reviews" },
  { to: "/location", label: "Location" },
] as const;

export function Navbar() {
  return (
    <nav className="fixed top-0 inset-x-0 z-50 h-[70px] px-[6%] flex items-center justify-between bg-white/90 backdrop-blur-xl border-b border-[color:var(--habib-yellow)]/30 shadow-[0_2px_28px_rgba(245,168,0,0.09)]">
      <Link to="/" className="flex items-center gap-3">
        <img src={habibLogo} alt="Al Habib Restaurants logo" width={48} height={48} className="h-12 w-auto object-contain" />
        <div className="leading-tight">
          <div style={{ fontFamily: "var(--font-display)" }} className="font-black text-[1.05rem] text-[color:var(--habib-black)]">
            Al Habib Restaurants
          </div>
          <div style={{ fontFamily: "var(--font-arabic)", direction: "rtl" }} className="text-[0.75rem] text-[color:var(--habib-grey)]">
            مطاعم الحبيب
          </div>
        </div>
      </Link>
      <ul className="hidden md:flex gap-8 list-none">
        {links.map((item) => (
          <li key={item.to}>
            <Link
              to={item.to}
              activeOptions={{ exact: true }}
              className="text-[0.93rem] font-bold transition-colors text-[color:var(--habib-charcoal)] hover:text-[color:var(--habib-yellow)] relative py-1"
              activeProps={{
                className:
                  "text-[0.93rem] font-bold text-[color:var(--habib-yellow)] relative py-1 after:absolute after:left-0 after:-bottom-1 after:h-[2px] after:w-full after:bg-[color:var(--habib-yellow)]",
              }}
            >
              {item.label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}
